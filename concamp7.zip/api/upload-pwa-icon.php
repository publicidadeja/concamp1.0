<?php
/**
 * API para upload de ícone PWA
 */

// Inclusão dos arquivos necessários
require_once '../config/config.php';
require_once '../includes/functions.php';

// Verificar autenticação
if (!isLoggedIn() || !isAdmin()) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Acesso não autorizado'
    ]);
    exit;
}

// Verificar token CSRF
if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Token de segurança inválido'
    ]);
    exit;
}

// Verificar se foi enviado um arquivo
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Nenhum arquivo enviado ou erro no upload'
    ]);
    exit;
}

// Verificar tipo e tamanho do arquivo
$allowed_types = ['image/jpeg', 'image/png', 'image/svg+xml'];
$max_size = 2 * 1024 * 1024; // 2MB

if (!in_array($_FILES['image']['type'], $allowed_types)) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Tipo de arquivo não permitido. Apenas JPG, PNG e SVG são permitidos.'
    ]);
    exit;
}

if ($_FILES['image']['size'] > $max_size) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Tamanho do arquivo excede o limite (2MB)'
    ]);
    exit;
}

// Criar diretório de ícones se não existir
$upload_dir = '../assets/img/icons/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Gerar nome de arquivo único com timestamp
$file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
$filename = 'icon-512x512.' . $file_ext;
$upload_path = $upload_dir . $filename;

// Mover arquivo para o diretório de uploads
if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
    // Caminho relativo para o banco de dados
    $relative_path = 'assets/img/icons/' . $filename;
    
    // Atualizar configuração no banco de dados
    updateSetting('pwa_icon_url', $relative_path);
    
    // Criar diferentes tamanhos de ícones para PWA
    $sizes = [72, 96, 128, 144, 152, 192, 384, 512];
    $sourceImage = null;
    
    // Carregar imagem de origem baseada no tipo
    switch ($_FILES['image']['type']) {
        case 'image/jpeg':
            $sourceImage = imagecreatefromjpeg($upload_path);
            break;
        case 'image/png':
            $sourceImage = imagecreatefrompng($upload_path);
            break;
        case 'image/svg+xml':
            // Para SVG, precisamos criar imagens PNG para cada tamanho
            // Como SVG é vetorial, não precisamos redimensionar, apenas criar uma cópia
            $relative_path = 'assets/img/icons/icon-512x512.svg';
            break;
    }
    
    // Criar as diferentes variantes de tamanho (exceto para SVG)
    if ($sourceImage && $_FILES['image']['type'] !== 'image/svg+xml') {
        foreach ($sizes as $size) {
            // Pular tamanho original
            if ($size == 512) continue;
            
            // Criar imagem redimensionada
            $destImage = imagecreatetruecolor($size, $size);
            
            // Preservar transparência para PNG
            if ($_FILES['image']['type'] === 'image/png') {
                imagealphablending($destImage, false);
                imagesavealpha($destImage, true);
                $transparent = imagecolorallocatealpha($destImage, 255, 255, 255, 127);
                imagefilledrectangle($destImage, 0, 0, $size, $size, $transparent);
            }
            
            imagecopyresampled($destImage, $sourceImage, 0, 0, 0, 0, $size, $size, imagesx($sourceImage), imagesy($sourceImage));
            
            // Salvar a imagem redimensionada
            $resizedFilename = 'icon-' . $size . 'x' . $size . '.' . ($file_ext === 'svg' ? 'png' : $file_ext);
            $resizedPath = $upload_dir . $resizedFilename;
            
            if ($_FILES['image']['type'] === 'image/jpeg') {
                imagejpeg($destImage, $resizedPath, 90);
            } else {
                imagepng($destImage, $resizedPath, 9);
            }
            
            imagedestroy($destImage);
        }
        
        // Limpar memória
        imagedestroy($sourceImage);
    }
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'file_path' => $relative_path
    ]);
} else {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao salvar o arquivo'
    ]);
}