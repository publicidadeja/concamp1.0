<?php
/**
 * Página do simulador principal
 */

// Título da página
$page_title = 'Simulador de Contrato Premiado';
$body_class = 'simulator-page';

// Incluir o conteúdo do simulador (compartilhado com as landing pages)
include __DIR__ . '/simulador-content.php';
?>
