<?php
$page_title = "Você está offline - ConCamp";
$body_class = "offline-page";
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        .offline-container {
            text-align: center;
            padding: 80px 0;
        }
        
        .offline-icon {
            font-size: 5rem;
            color: #6c757d;
            margin-bottom: 30px;
        }
        
        .offline-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: #343a40;
        }
        
        .offline-text {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto 30px;
            color: #6c757d;
        }
    </style>
</head>
<body class="<?php echo $body_class; ?>">
    <div class="container">
        <div class="offline-container">
            <div class="offline-icon">
                <i class="fas fa-wifi-slash"></i>
            </div>
            <h1 class="offline-title">Você está offline</h1>
            <p class="offline-text">Parece que você perdeu a conexão com a internet. Verifique sua conexão e tente novamente.</p>
            <button class="btn btn-primary" onclick="window.location.reload()">
                <i class="fas fa-sync-alt me-2"></i> Tentar novamente
            </button>
        </div>
    </div>
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>