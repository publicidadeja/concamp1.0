/**
 * ConCamp PWA - Script para gerenciar funcionalidades de Progressive Web App
 */

// Variáveis para controle da instalação do PWA
let deferredPrompt;
const pwaInstalled = localStorage.getItem('pwa_installed') === 'true';
const firstAccess = localStorage.getItem('first_access') !== 'false';

// Registrar o Service Worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('Service Worker registrado com sucesso:', registration);
            })
            .catch(error => {
                console.error('Erro ao registrar Service Worker:', error);
            });
    });
}

// Escutar evento beforeinstallprompt para capturar prompt de instalação
window.addEventListener('beforeinstallprompt', (e) => {
    // Prevenir Chrome 67+ de mostrar automaticamente o prompt
    e.preventDefault();
    
    // Guardar o evento para mostrar mais tarde
    deferredPrompt = e;
    
    // Verificar se o usuário está logado (verificamos através de um atributo no corpo)
    const isLoggedIn = document.body.classList.contains('dashboard-page') || 
                       document.body.classList.contains('admin-page');
                       
    // Verificar se é o primeiro acesso e o usuário está logado
    if (firstAccess && isLoggedIn && !pwaInstalled) {
        // Mostrar modal depois de 3 segundos
        setTimeout(() => {
            showInstallPrompt();
        }, 3000);
    }
});

// Função para mostrar o modal de instalação PWA
function showInstallPrompt() {
    // Criar modal dinamicamente
    const modalHtml = `
    <div class="modal fade" id="pwaInstallModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Instalar ConCamp como aplicativo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-4">
                        <i class="fas fa-mobile-alt fa-4x text-primary mb-3"></i>
                        <p>Instale o ConCamp em seu dispositivo para ter acesso mais rápido e uma experiência melhorada, mesmo offline!</p>
                    </div>
                    <div class="d-flex align-items-center border rounded p-3 mb-3">
                        <i class="fas fa-check-circle text-success me-3 fa-2x"></i>
                        <div>
                            <h6 class="mb-1">Acesso rápido</h6>
                            <p class="mb-0 small text-muted">Abra diretamente da tela inicial do seu dispositivo</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border rounded p-3 mb-3">
                        <i class="fas fa-check-circle text-success me-3 fa-2x"></i>
                        <div>
                            <h6 class="mb-1">Funciona offline</h6>
                            <p class="mb-0 small text-muted">Acesse recursos básicos mesmo sem internet</p>
                        </div>
                    </div>
                    <div class="d-flex align-items-center border rounded p-3">
                        <i class="fas fa-check-circle text-success me-3 fa-2x"></i>
                        <div>
                            <h6 class="mb-1">Experiência de aplicativo nativo</h6>
                            <p class="mb-0 small text-muted">Interface otimizada para seu dispositivo</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="pwaLater">Mais tarde</button>
                    <button type="button" class="btn btn-primary" id="pwaInstall">
                        <i class="fas fa-download me-2"></i>Instalar agora
                    </button>
                </div>
            </div>
        </div>
    </div>`;
    
    // Adicionar modal ao corpo da página
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Inicializar o modal
    const modalElement = document.getElementById('pwaInstallModal');
    const modal = new bootstrap.Modal(modalElement);
    
    // Mostrar o modal
    modal.show();
    
    // Adicionar tratadores de eventos aos botões
    document.getElementById('pwaInstall').addEventListener('click', () => {
        // Esconder o modal
        modal.hide();
        
        // Mostrar o prompt de instalação do navegador
        if (deferredPrompt) {
            deferredPrompt.prompt();
            
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('Usuário aceitou a instalação do PWA');
                    localStorage.setItem('pwa_installed', 'true');
                } else {
                    console.log('Usuário recusou a instalação do PWA');
                }
                
                deferredPrompt = null;
            });
        }
    });
    
    // Ação para o botão "Mais tarde"
    document.getElementById('pwaLater').addEventListener('click', () => {
        localStorage.setItem('first_access', 'false');
    });
    
    // Quando o modal for escondido
    modalElement.addEventListener('hidden.bs.modal', () => {
        localStorage.setItem('first_access', 'false');
    });
}

// Detectar quando o PWA foi instalado
window.addEventListener('appinstalled', (evt) => {
    console.log('ConCamp PWA foi instalado');
    localStorage.setItem('pwa_installed', 'true');
    
    // Esconder o modal se estiver aberto
    const modalElement = document.getElementById('pwaInstallModal');
    if (modalElement) {
        const modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) {
            modal.hide();
        }
    }
});