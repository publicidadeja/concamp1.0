<?php
/**
 * API para upload de favicon
 */

// Inclusão dos arquivos necessários
require_once '../config/config.php';
require_once '../includes/functions.php';

// Verificar autenticação
if (!isLoggedIn() || !isAdmin()) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Acesso não autorizado'
    ]);
    exit;
}

// Verificar token CSRF
if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Token de segurança inválido'
    ]);
    exit;
}

// Verificar se foi enviado um arquivo
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Nenhum arquivo enviado ou erro no upload'
    ]);
    exit;
}

// Verificar tipo e tamanho do arquivo
$allowed_types = ['image/jpeg', 'image/png', 'image/svg+xml', 'image/x-icon', 'image/vnd.microsoft.icon'];
$max_size = 2 * 1024 * 1024; // 2MB

if (!in_array($_FILES['image']['type'], $allowed_types)) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Tipo de arquivo não permitido. Apenas JPG, PNG, SVG e ICO são permitidos.'
    ]);
    exit;
}

if ($_FILES['image']['size'] > $max_size) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Tamanho do arquivo excede o limite (2MB)'
    ]);
    exit;
}

// Criar diretório de ícones se não existir
$upload_dir = '../assets/img/icons/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Gerar nome de arquivo único com timestamp
$file_ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
$filename = 'favicon.' . $file_ext;
$upload_path = $upload_dir . $filename;

// Mover arquivo para o diretório de uploads
if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
    // Caminho relativo para o banco de dados
    $relative_path = 'assets/img/icons/' . $filename;
    
    // Atualizar configuração no banco de dados
    updateSetting('favicon_url', $relative_path);
    
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'file_path' => $relative_path
    ]);
} else {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao salvar o arquivo'
    ]);
}