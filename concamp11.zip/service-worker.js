// Service Worker para ConCamp - Sistema de Contratos Premiados
const CACHE_NAME = 'concamp-v2'; // Incrementamos a versão
const APP_PREFIX = 'concamp'; // Prefixo para identificar os caches da aplicação

// URLs para serem cacheadas durante a instalação
const urlsToCache = [
  // Arquivos CSS
  '/assets/css/style.css',
  '/assets/css/dashboard.css',
  '/assets/css/hardcoded-theme.css',
  '/assets/css/theme.php',
  
  // Arquivos JavaScript
  '/assets/js/app.js',
  '/assets/js/dashboard.js',
  '/assets/js/notifications.js',
  '/assets/js/simulador.js',
  '/assets/js/pwa.js',
  
  // Bibliotecas externas
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
  'https://unpkg.com/imask',
  
  // Ícones e imagens importantes
  '/assets/img/icons/favicon.png',
  '/assets/img/icons/icon-72x72.png',
  '/assets/img/icons/icon-96x96.png',
  '/assets/img/icons/icon-128x128.png',
  '/assets/img/icons/icon-144x144.png',
  '/assets/img/icons/icon-152x152.png',
  '/assets/img/icons/icon-192x192.png',
  '/assets/img/icons/icon-384x384.png',
  '/assets/img/icons/icon-512x512.png',
  
  // Páginas principais
  '/index.php',
  '/index.php?route=dashboard',
  '/index.php?route=leads',
  '/index.php?route=login',
  '/manifest.json',
  '/offline.php'
];

// Instalação do Service Worker
self.addEventListener('install', event => {
  // Realizar etapa de instalação
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache aberto');
        return cache.addAll(urlsToCache);
      })
  );
});

// Ativação do Service Worker
self.addEventListener('activate', event => {
  // Manter apenas o cache atual e remover versões antigas
  const cacheWhitelist = [CACHE_NAME];
  
  event.waitUntil(
    // Obter todas as chaves de cache e limpar as versões antigas
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          // Se o cache pertence a esta aplicação (tem o prefixo) e não está na lista whitelist
          if (cacheName.startsWith(APP_PREFIX) && cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Service Worker: Removendo cache antigo:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      // Forçar que o service worker assuma o controle deste cliente imediatamente
      console.log('Service Worker: Ativado e controlando a página');
      return self.clients.claim();
    })
  );
});

// Interceptação de solicitações para cache/rede
self.addEventListener('fetch', event => {
  // Endereços que não devem ser cacheados
  const apiUrls = ['/api/', '?route=api-', 'upload-', '/admin-', 'notifications', '?route=notifications'];
  // Permitir que o url de notificações com parâmetro ref=header seja processado corretamente
  const shouldNotCache = event.request.method !== 'GET' || 
                        apiUrls.some(url => {
                          if (url === 'notifications' || url === '?route=notifications') {
                            // Incluir notificações no cache apenas se vier do ícone do header e tiver role
                            return event.request.url.includes(url) && 
                                 !(event.request.url.includes('ref=header') && 
                                   event.request.url.includes('role='));
                          }
                          return event.request.url.includes(url);
                        });
  
  // Não interceptar requisições para APIs, POSTs, endpoints sensíveis ou notificações
  if (shouldNotCache) {
    return;
  }
  
  // Estratégia: Cache-First com fallback para rede e offline
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        // 1. Primeiro verificamos se temos a resposta no cache
        if (cachedResponse) {
          console.log('Service Worker: Usando cache para:', event.request.url);
          return cachedResponse;
        }
        
        // 2. Se não estiver no cache, tentar buscar da rede
        console.log('Service Worker: Buscando da rede:', event.request.url);
        return fetch(event.request.clone())
          .then(networkResponse => {
            // Verificar se recebemos uma resposta válida
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              console.log('Service Worker: Resposta não cacheável:', event.request.url);
              return networkResponse;
            }
            
            // Armazenar em cache a resposta da rede para uso futuro
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME)
              .then(cache => {
                console.log('Service Worker: Armazenando no cache:', event.request.url);
                cache.put(event.request, responseToCache);
              })
              .catch(error => {
                console.error('Service Worker: Erro ao armazenar em cache:', error);
              });
              
            return networkResponse;
          })
          .catch(error => {
            console.log('Service Worker: Falha na rede, usando fallback para:', event.request.url);
            
            // 3. Se a rede falhar, mostrar página offline para solicitações HTML
            if (event.request.headers.get('Accept')?.includes('text/html')) {
              return caches.match('/offline.php');
            }
            
            // Para outros recursos (CSS, JS), apenas retornar o erro
            return Promise.reject(error);
          });
      })
  );
});