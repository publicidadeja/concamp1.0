// Service Worker para ConCamp - Sistema de Contratos Premiados
const CACHE_NAME = 'concamp-v1';
const urlsToCache = [
  '/assets/css/style.css',
  '/assets/css/dashboard.css',
  '/assets/css/hardcoded-theme.css',
  '/assets/js/app.js',
  '/assets/js/dashboard.js',
  '/assets/js/notifications.js',
  '/assets/js/simulador.js',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css',
  '/index.php',
  '/index.php?route=dashboard',
  '/offline.php'
];

// Instalação do Service Worker
self.addEventListener('install', event => {
  // Realizar etapa de instalação
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache aberto');
        return cache.addAll(urlsToCache);
      })
  );
});

// Ativação do Service Worker
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Interceptação de solicitações para cache/rede
self.addEventListener('fetch', event => {
  // Verificar se a solicitação é para uma API ou um POST - não cacheamos
  if (event.request.method !== 'GET' || 
      event.request.url.includes('/api/') || 
      event.request.url.includes('?route=api-')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - retorna a resposta do cache
        if (response) {
          return response;
        }

        // Clone da solicitação original - streams só podem ser lidos uma vez
        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          response => {
            // Verificar se recebemos uma resposta válida
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone da resposta - streams só podem ser lidos uma vez
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                // Armazenar em cache a resposta da rede
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        ).catch(() => {
          // Se falhar na rede e for uma página HTML, mostrar página offline
          if (event.request.headers.get('Accept').includes('text/html')) {
            return caches.match('/offline.php');
          }
        });
      })
  );
});