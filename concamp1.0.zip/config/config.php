<?php
// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'conc_concamp');
define('DB_USER', 'conc_concamp');
define('DB_PASS', '@Speaker120123');

// Configurações da aplicação
define('APP_NAME', 'ConCamp');
define('APP_URL', 'https://concamp.publicidadeja.com.br');
define('WHATSAPP_API_URL', 'https://api2.publicidadeja.com.br/api/messages/send');
define('WHATSAPP_API_TOKEN', '12121212');

// Não altere as configurações abaixo
define('PATH_ROOT', __DIR__ . '/..');
?>