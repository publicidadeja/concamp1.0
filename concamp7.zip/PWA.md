# Progressive Web App (PWA) - ConCamp

Este documento explica como o ConCamp implementa a funcionalidade de PWA (Progressive Web App), que permite a instalação do sistema como um aplicativo nativo em dispositivos móveis e desktop.

## O que é um PWA?

Um PWA (Progressive Web App) é uma aplicação web que usa tecnologias modernas para oferecer uma experiência similar a um aplicativo nativo. Os PWAs podem ser instalados na tela inicial de dispositivos móveis ou no desktop, funcionam offline e oferecem uma experiência de usuário mais rápida e integrada.

## Características do PWA do ConCamp

1. **Instalável**: Os usuários podem adicionar o ConCamp à tela inicial ou ao menu de aplicativos.
2. **Funciona offline**: Recursos básicos permanecem acessíveis mesmo sem conexão com a internet.
3. **Experiência similar a app nativo**: Interface otimizada que se comporta como um aplicativo nativo.
4. **Notificações para usuários logados**: Durante o primeiro acesso, mostra um modal convidando à instalação.

## Arquivos do PWA

Os principais arquivos que compõem a funcionalidade PWA são:

1. **includes/generate-manifest.php**: Gera dinamicamente o arquivo manifest.json com as configurações personalizadas.
2. **service-worker.js**: Gerencia o cache e o comportamento offline.
3. **assets/js/pwa.js**: Script que controla a detecção de instalação e exibe o modal.
4. **offline.php**: Página exibida quando não há conexão com a internet.
5. **assets/img/icons/**: Diretório com ícones em vários tamanhos para diferentes dispositivos.

## Configurações do Administrador

Como administrador, você pode personalizar o PWA através do painel de configurações:

1. **Acesse** "Administração > Configurações".
2. **Navegue** até a seção "Progressive Web App (PWA)".
3. **Ative/Desative** o PWA usando a opção "Ativar Progressive Web App".
4. **Personalize** as seguintes opções:
   - Nome do Aplicativo: Nome completo exibido durante a instalação
   - Nome Curto: Nome exibido abaixo do ícone na tela inicial
   - Descrição: Descrição breve exibida durante a instalação
   - Cor do Tema: Cor da barra de título do aplicativo
   - Cor de Fundo: Cor exibida durante o carregamento
   - Ícone do PWA: Imagem exibida na tela inicial (512x512px recomendado)

Além disso, você pode personalizar o favicon que aparece na aba do navegador na seção "Favicon e Ícones".

## Funcionamento do Modal de Instalação

O modal de instalação é exibido apenas para usuários logados (administradores ou vendedores) durante seu primeiro acesso ao sistema. Este comportamento é controlado por duas variáveis no localStorage:

- `first_access`: Indica se é o primeiro acesso do usuário.
- `pwa_installed`: Indica se o PWA já foi instalado.

## Como Testar o PWA

Para testar a funcionalidade PWA:

1. Acesse o ConCamp em um navegador moderno (Chrome, Edge, Firefox ou Safari).
2. Faça login no sistema.
3. No primeiro acesso, após alguns segundos, um modal aparecerá convidando para a instalação.
4. Para instalar manualmente:
   - No Chrome/Edge (desktop): Clique no ícone "+" na barra de endereço.
   - No Chrome (Android): Toque em "Adicionar à tela inicial" no menu.
   - No Safari (iOS): Toque em "Compartilhar" e depois "Adicionar à Tela de Início".

## Teste de Funcionalidade Offline

Para testar a funcionalidade offline:

1. Instale o ConCamp como PWA.
2. Navegue por algumas páginas para que sejam armazenadas em cache.
3. Desative sua conexão com a internet (modo avião ou desconecte do Wi-Fi).
4. Tente acessar as páginas anteriormente visitadas - devem funcionar offline.
5. Se tentar acessar uma página não visitada anteriormente, verá a página offline.

## Geração Automática de Ícones

Quando você faz upload de um ícone PWA na página de configurações, o sistema automaticamente:

1. Salva o ícone original (normalmente 512x512 pixels).
2. Gera versões redimensionadas para vários tamanhos (72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384).
3. Atualiza o manifest.json para incluir todos os tamanhos de ícones.

Se você enviar um ícone SVG, ele será usado diretamente em todos os tamanhos, sem redimensionamento, aproveitando a natureza vetorial do formato.

## Considerações Técnicas

- O manifest.json é gerado dinamicamente com base nas configurações personalizadas do administrador.
- O cache é gerenciado no arquivo service-worker.js e configurado para armazenar recursos estáticos e páginas visitadas.
- As requisições à API e operações POST não são armazenadas em cache para garantir consistência dos dados.
- O modal de instalação usa Bootstrap para o layout e é injetado dinamicamente no DOM quando necessário.

## Solução de Problemas

Se o PWA não estiver funcionando corretamente:

1. Verifique se a opção "Ativar Progressive Web App" está habilitada nas configurações.
2. Certifique-se de que o ícone do PWA foi carregado corretamente.
3. Teste em diferentes navegadores (Chrome é geralmente o mais compatível com PWAs).
4. Limpe o cache do navegador e tente novamente.
5. Verifique se o service-worker.js está acessível e não está sendo bloqueado pelo servidor.